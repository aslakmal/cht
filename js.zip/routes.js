// This file is required by app.js. It sets up event listeners
// for the two main URL endpoints of the application - /create and /chat/:id
// and listens for socket.io messages.

// Use the gravatar module, to turn email addresses into avatar images:

var gravatar = require('gravatar');
//var mysql = require('mysql');
// Export a function, so that we can pass 
// the app and io instances from the app.js file:
var formidable = require('formidable');
var fs = require('fs');

module.exports = function(app,io){
/*var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: ""
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
}); */

	app.get('/post', function(req, res){ console.log('334ed');
     var form = new formidable.IncomingForm();
    form.parse(req, function (err, fields, files) {
      var oldpath = files.filetoupload.path;
      var newpath = '' + files.filetoupload.name;
      fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
        res.write('File uploaded and moved!');
        res.end();
      });
 });
	});
	
	app.get('/', function(req, res){
         res.render('chat');
	});

	app.get('/chat/:id', function(req,res){

		// Render the chat.html view
		res.render('chat');
	});

	// Initialize a new socket.io application, named 'chat'
	var chat = io.on('connection', function (socket) {
                // When the client emits the 'load' event, reply with the 
		// number of people in this chat room
        socket.on('load',function(data){
	var room = findClientsSocket(io,data);
		socket.emit('peopleinchat', {number:room.length});
		});

		// When the client emits 'login', save his name and avatar,
		// and add them to the room
		socket.on('login', function(data) {

			var room = findClientsSocket(io, data.id);
			console.log(room);
                        // Only two people per room are allowed
			//if (room.length < 2) {

				// Use the socket object to store data. Each client gets
				// their own unique socket object

				socket.username = data.user;
				socket.room = data.id;
				socket.avatar = data.avatar;

				// Tell the person what he should use for an avatar
				socket.emit('img', socket.avatar);


				// Add the client to the room
				socket.join(data.id);

				//if (room.length == 1) {

					var users = [];
                                             /*  */
                                               
                                     if(!users.some(function(o){return o["username"] === socket.username;})){
										 users.push({
                                            username:socket.username,
                                            avatar:socket.avatar
                                             }); 
									 } 
                                                for(i in room){
					users.push({
                                            username:room[i].username,
                                            avatar:room[i].avatar
                                           });
					 }
					// Send the startChat event to all the people in the
					// room, along with a list of people that are in it.

					chat.in(data.id).emit('startChat', {
						boolean: true,
						id: data.id,
						users: users,
					});
		});

		// Somebody left the chat
		socket.on('disconnect', function() {

			// Notify the other person in the chat room
			// that his partner has left
var users = [];
var roomarr = findClientsSocket(io, this.room);
                 for(i in roomarr){
					users.push({
                                            username:roomarr[i].username,
                                            avatar:roomarr[i].avatar
                                           });
					 }          
			socket.broadcast.to(this.room).emit('leave', {
				boolean: true,
				room: this.room,
				user: this.username,
				avatar: this.avatar,
                                users:users
			});

			// leave the room
			socket.leave(socket.room);
		});
socket.on('typing', function (data) {
      socket.broadcast.to(socket.room).emit('typing', data);
    });
socket.on('stoptyping', function (data) {
      socket.broadcast.to(socket.room).emit('stoptyping', data);
    });
	// Handle the sending of messages
		socket.on('msg', function(data){
                      socket.broadcast.to(socket.room).emit('receive', {msg: data.msg, user: data.user, img: data.img});
		});
	});
};

function findClientsSocket(io,roomId, namespace) {
	var res = [],
		ns = io.of(namespace ||"/");    // the default namespace is "/"

	if (ns) {
		for (var id in ns.connected) {
			if(roomId) {
				var index = ns.connected[id].rooms.indexOf(roomId) ;
				if(index !== -1) {
					res.push(ns.connected[id]);
				}
			}
			else {
				res.push(ns.connected[id]);
			}
		}
	}
	return res;
}


