// This file is executed in the browser, when people visit /chat/<random id>

$(function(){
    var id = '';
// getting the id of the room from the url
if(window.location.pathname=='/'){
    id='public';
}else{
  id=Number(window.location.pathname.match(/\/chat\/(\d+)$/)[1]);
  }
 	
        
// connect to the socket
	var socket = io();
	
	// variables which hold the data for each person
	var name = "",
		img = "",
		friend = "",
		tfisset = "",
		istyping = "",
		msgtext="";
	// cache some jQuery objects
	var section = $(".section"),
		footer = $("footer"),
		onConnect = $(".connected"),
		inviteSomebody = $(".invite-textfield"),
		personInside = $(".personinside"),
		chatScreen = $(".chatscreen"),
		left = $(".left"),
		noMessages = $(".nomessages");
		
	// some more jquery objects
	var chatNickname = $(".nickname-chat"),
		leftNickname = $(".nickname-left"),
		chatForm = $("#chatform"),
		textarea = $("#message"),
		messageTimeSent = $(".timesent"),
		chats = $(".chats");
	// these variables hold images
	var ownerImage = $("#ownerImage"),
		leftImage = $("#leftImage"),
		noMessagesImage = $("#noMessagesImage"),
                userdetails="";
                
            //$('.connected').show();
                $('.loginForm').submit(function(e){
            e.preventDefault();
            if($('#yourName').val()){
         userdetails={username:$('#yourName').val()};  
            }else{
           alert('please add an username');     
            }
        });
       // on connection to server get the id of person's room
	   	/*	socket.on('connect', function(){
	socket.emit('load', id);
	});*/
	
$('.guest-login').click(function(e){ 
 e.preventDefault();
 if($('.guestname').val()){
if(name==''){
	 name=$('.guestname').val();
document.getElementById('id01').style.display='none';
	socket.emit('load', id);
	// save the gravatar url
	socket.on('img', function(data){
		img = data;
	});
	// receive the names and avatars of all people in the chat room
	socket.on('peopleinchat', function(data){
  socket.emit('login', {
      user: name,
      avatar:'http://www.gravatar.com/avatar/d41d8cd98f00b204e9800998ecf8427e?s=140&r=x&d=mm',
      id: id
  });
	}); 
 }
 }
});

	
	// Other useful 
	socket.on('startChat', function(data){
            $('.online_members').html('');
            for(i in data.users){
                var conv=' <li class="user"><div class="image"><img src="'+data.users[i].avatar+'">'+
                    '<b></b> </div>'+
                '<p>'+data.users[i].username+'</p></li>';
        $('.online_members').append(conv);
             }
            footer.fadeIn(1200);
		/*if(data.boolean && data.id == id) {
			//chats.empty();
			if(name === data.users[0]) {
				showMessage("youStartedChatWithNoMessages",data);
			}
			else {
				showMessage("heStartedChatWithNoMessages",data);
			}
		chatNickname.text(friend);
		} */
	});

	socket.on('leave',function(data){
		if(data.boolean && id==data.room){
		 $('.conversations').html('');
            for(i in data.users){
                var conv=' <li class="user"><div class="image"><img src="'+data.users[i].avatar+'">'+
                    '<b></b> </div>'+
                '<p>'+data.users[i].username+'</p></li>';
        $('.conversations').append(conv);
             }
         	//chats.empty();
		}
});

	socket.on('tooMany', function(data){
		if(data.boolean && name.length === 0) {
			showMessage('cannotjoin');
		}
	});

	socket.on('receive', function(data){
		showMessage('chatStarted');
                if(data.msg.trim().length) {
			createChatMessage(data.msg, data.user, data.img, moment());
			scrollToBottom();
		}
	});
        
	socket.on('typing', function(data){
         typing(data);
	});
        
        socket.on('stoptyping', function(data){
         stoptyping(data);
	});

	textarea.keyup(function(e){
        // Submit the form on enter
                if(e.which == 13) {
					 if(name==''){document.getElementById('id01').style.display='block'; return false; }
			e.preventDefault();
			chatForm.trigger('submit');
		}else{
	  if(tfisset==''){checktyping(socket);}
             if(istyping==''){
              socket.emit('typing',  {username:name});
          }
	       }
	});
		
		//check typing
	function checktyping(socket){	
            tfisset=1;
            var ct=setInterval(function(){
	if(textarea.val()!=msgtext){
		msgtext=textarea.val();	
              if(istyping==''){
                  istyping=1;
		  
 socket.emit('typing',  {username:name});
              }	}
			else{
                            istyping='';
                            tfisset='';
                            clearInterval(ct);
                           
 socket.emit('stoptyping',  {username:name});			
			}
	},500);
        }	



	chatForm.on('submit', function(e){ 
		 if(name==''){document.getElementById('id01').style.display='block'; return false; }
					e.preventDefault();

		// Create a new chat message and display it directly

		showMessage("chatStarted");

		if(textarea.val().trim().length) {
                    socket.emit('stoptyping',  {username:name});	
			createChatMessage(textarea.val(), name, img, moment());
			scrollToBottom();

			// Send the message to the other person in the chat
			socket.emit('msg', {msg: textarea.val(), user: name, img: img});

		}
		// Empty the textarea
		textarea.val("");
	});
   
	
	// Update the relative time stamps on the chat messages every minute

	setInterval(function(){

		messageTimeSent.each(function(){
			var each = moment($(this).data('time'));
			$(this).text(each.fromNow());
		});

	},60000);

	// Function that creates a new chat message

	function createChatMessage(msg,user,imgg,now){

		var who = '';

		if(user===name) {
			who = 'me';
		}
		else {
			who = 'you';
		}

		var li = $(
			'<li class=' + who + '>'+
				'<div class="image">' +
					'<img src=' + imgg + ' />' +
					'<b></b>' +
					'' +
				'</div>' +
				'<p>'+ msg +'<i class="timesent" data-time=' + now + '></i> </p>' +
			'</li>');

		// use the 'text' method to escape malicious user input
		//li.find('p').text(msg);
		li.find('b').text(user);

		chats.append(li);

		messageTimeSent = $(".timesent");
		messageTimeSent.last().text(now.fromNow());
	}

	
	
	
	
	
	
	function scrollToBottom(){
		$(".chats").animate({ scrollTop:$('.chats').prop("scrollHeight") },1000);
	}

	function isValid(thatemail) {var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(thatemail);
	}

	
	
	
	function showMessage(status,data){

		if(status === "connected"){

			section.children().css('display', 'none');
			onConnect.fadeIn(1200);
		}

		else if(status === "inviteSomebody"){

			// Set the invite link content
			$("#link").text(window.location.href);

			onConnect.fadeOut(1200, function(){
				inviteSomebody.fadeIn(1200);
			});
		}

		else if(status === "personinchat"){

			onConnect.css("display", "none");
			personInside.fadeIn(1200);

			chatNickname.text(data.user);
			ownerImage.attr("src",data.avatar);
		}

		else if(status === "youStartedChatWithNoMessages") {

			left.fadeOut(1200, function() {
				inviteSomebody.fadeOut(1200,function(){
					noMessages.fadeIn(1200);
					footer.fadeIn(1200);
				});
			});

			friend = data.users[1];
			noMessagesImage.attr("src",data.avatars[1]);
		}

		else if(status === "heStartedChatWithNoMessages") {

			personInside.fadeOut(1200,function(){
				noMessages.fadeIn(1200);
				footer.fadeIn(1200);
			});

			friend = data.users[0];
			noMessagesImage.attr("src",data.avatars[0]);
		}

		else if(status === "chatStarted"){

			section.children().css('display','none');
			chatScreen.css('display','block');
		}

		else if(status === "somebodyLeft"){

			leftImage.attr("src",data.avatar);
			leftNickname.text(data.user);

			section.children().css('display','none');
			footer.css('display', 'none');
			left.fadeIn(1200);
		}

		else if(status === "cannotjoin") {

			section.children().css('display', 'none');
			cannotjoin.fadeIn(1200);
		}
	}
        var typ=0;
function typing(data){
    var dot='<b class="jumping-dots"><b class="dot-1">.</b><b class="dot-2">.</b><b class="dot-3">.</b></b>';
$('#typing').html(data.username+' is typing '+dot);
if(typ==0){
	 $("#typing").animate({'margin-top': "-20px"});
     typ=1;}
     }
function stoptyping(){
 if(typ==1){
	 $("#typing").animate({'margin-top': "0"});
     typ=0;}
}
var mmenushow=0;
$('.mobile-menu-btn').click(function(){
    if(mmenushow==0){
    $('.convodiv').css('display','block');
    $('.convodiv').animate({'right':'0'});
    $('.mobile-menu-btn').addClass('open');
mmenushow=1;
}else{
    $('.convodiv').animate({'right':'-100%'},function(){
       $('.convodiv').css('display','none');  
    });
  mmenushow=0;
  $('.mobile-menu-btn').removeClass('open');
}
});
var emoji=0;
var imgelm=$('.emotes .emotes_list');
$('.show_imotes').click(function(){
	if(emoji==0){
		emoji=1;
    imgelm.show(200); 
    var imgs='';
for(i=1;i<123;i++){
  imgs+='<img src="../emotes/gif-emote ('+i+').gif" width="50">';  
  }
for(i=1;i<3;i++){
  imgs+='<img src="../emotes/png-emote ('+i+').png" width="50">';  
  }
  imgs+='<img src="../emotes/bmp-emote.bmp" width="50">';  
  $('.emotes .emotes_list').html('<div>'+imgs+'</div>');
       $('.emotes .emotes_list img').click(function(){ 
	  if(name==''){document.getElementById('id01').style.display='block'; return false; }
			    showMessage("chatStarted");
             createChatMessage('<img src="'+this.src+'">', name, img, moment());
			scrollToBottom();
                  socket.emit('msg', {msg:'<img src="'+this.src+'">', user: name, img: img});
              $('.emotes .emotes_list').hide(200);     
});
  }else{
	 imgelm.hide(200);  
emoji=0;	 
  }
});

$('.senddiv_in .fa-paperclip,.senddiv_in .fa-chevron-circle-right').click(function(){
	if(emoji==1){
	imgelm.hide(200);  
emoji=0;	
	}
});
$('[data-toggle="tooltip"]').tooltip();  
});
